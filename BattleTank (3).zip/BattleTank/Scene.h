#ifndef SCENE_H
#define SCENE_H

#include "Enemy.h"
#include "Bullet.h"
#include <QGraphicsScene>
#include <QTimer>
#include <QObject>

class Scene : public QGraphicsScene
{
    Q_OBJECT
public:
    explicit Scene(QObject *parent = nullptr);

signals:

private:
    //Enemy *enemy;
    Basic *basic;
    Fast *fast;
    Power *power;
    Armor *armor;
    QTimer *timer;
    Bullet *bullet;
};

#endif // SCENE_H
