#include "Bullet.h"
#include "Enemy.h"

Bullet::Bullet()
{
    setPixmap(QPixmap(":/image/bullet.png"));
    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Bullet::move );
    timer->start(50);
}

void Bullet::move()
{
    setPos(x() , y() + 50);
}

