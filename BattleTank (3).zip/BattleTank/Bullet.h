#ifndef BULLET_H
#define BULLET_H


#include <QTimer>
#include <QObject>
#include <QGraphicsPixmapItem>

class Bullet : public QObject ,public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    Bullet();
    //~Bullet();

public slots:
    //void spawn();
    void move();

signals:
    //void bullethitsEnemy(Bullet *bullet , Enemy *enemy);

private:
    QTimer *timer;
};

#endif // BULLET_H
