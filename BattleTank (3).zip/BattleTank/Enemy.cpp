#include "Enemy.h"
#include "QGraphicsScene"
#include <stdlib.h>
#include <QtGlobal>
#include <ctime>

/*Enemy::Enemy()
{
    setPixmap(QPixmap(":/image/Basic_Tank.png"));
    srand(time(NULL));
    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Enemy::move );
    timer->start(100);
}

Enemy::~Enemy()
{
    delete timer;
}

void Enemy::move()
{
    int n = rand() % 4;

    switch (n) {
    case 0:
        setPos(x() , y() + 20);
        break;
    case 1:
        setPos(x() , y() - 5);
        break;
    case 2:
        setPos(x() + 5 , y());
        break;
    default:
        setPos(x() - 5 , y());
        break;
    }
    //setPos(x() , y() + 5);
}*/

Basic::Basic()
{
    setPixmap(QPixmap(":/image/Basic_Tank.png"));
    srand(time(NULL));
    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Enemy::move );
    timer->start(100);
}

void Basic::move()
{
    dir = rand() % 4;

    switch (dir) {
    case 0:
        setRotation(90);
        setPos(x() , y() + 20);
        break;
    case 1:
        setRotation(0);
        setPos(x() , y() - 20);
        break;
    case 2:
        setRotation(180);
        setPos(x() + 20 , y());
        break;
    default:
        setRotation(270);
        setPos(x() - 20 , y());
        break;
    }
}



Fast::Fast()
{
    setPixmap(QPixmap(":/image/Fast_Tank.png"));
    srand(time(NULL));
    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Enemy::move );
    timer->start(100);
}

void Fast::move()
{
    dir = rand() % 4;

    switch (dir) {
    case 0:
        setRotation(90);
        setPos(x() , y() + 5);
        break;
    case 1:
        setRotation(0);
        setPos(x() , y() - 5);
        break;
    case 2:
        setRotation(180);
        setPos(x() + 5 , y());
        break;
    default:
        setRotation(270);
        setPos(x() - 5 , y());
        break;
    }
}

Power::Power()
{
    setPixmap(QPixmap(":/image/Power_Tank.png"));
    srand(time(NULL));
    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Enemy::move );
    timer->start(100);
}

void Power::move()
{
    dir = rand() % 4;

    switch (dir) {
    case 0:
        setRotation(90);
        setPos(x() , y() + 5);
        break;
    case 1:
        setRotation(0);
        setPos(x() , y() - 5);
        break;
    case 2:
        setRotation(180);
        setPos(x() + 5 , y());
        break;
    default:
        setRotation(270);
        setPos(x() - 5 , y());
        break;
    }
}

Armor::Armor()
{
    setPixmap(QPixmap(":/image/Armor_Tank.png"));
    srand(time(NULL));
    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Enemy::move );
    timer->start(100);
}

void Armor::move()
{
    dir = rand() % 4;

    switch (dir) {
    case 0:
        setRotation(90);
        setPos(x() , y() + 5);
        break;
    case 1:
        setRotation(0);
        setPos(x() , y() - 5);
        break;
    case 2:
        setRotation(180);
        setPos(x() + 5 , y());
        break;
    default:
        setRotation(270);
        setPos(x() - 5 , y());
        break;
    }
}

qreal Enemy::rotation() const
{
    return m_rotation;
}

void Enemy::setRotation(qreal newRotation)
{
    m_rotation = newRotation;
    QPointF c =boundingRect().center();
    QTransform t;
    t.translate(c.x(),c.y());
    t.rotate(newRotation);
    t.translate(-c.x(),-c.y());
    setTransform(t);
}
