#include "Scene.h"

Scene::Scene(QObject *parent)
    : QGraphicsScene{parent}
{
    basic = new Basic();
    basic->setPos(50,50);
    addItem(basic);

    fast = new Fast();
    fast->setPos(200,200);
    addItem(fast);

    power = new Power();
    power->setPos(350,350);
    addItem(power);

    armor = new Armor();
    armor->setPos(500,500);
    addItem(armor);


    timer = new QTimer();
    connect(timer, &QTimer::timeout, [=](){
        bullet = new Bullet();
        bullet->setPos(basic->pos()+QPointF(20,20));
        addItem(bullet);
    });
    timer->start(50);
}
