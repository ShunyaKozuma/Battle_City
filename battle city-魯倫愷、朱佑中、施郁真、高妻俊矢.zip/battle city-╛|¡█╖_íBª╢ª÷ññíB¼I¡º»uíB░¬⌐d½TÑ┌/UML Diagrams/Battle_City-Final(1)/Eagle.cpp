#include "Eagle.h"

Eagle::Eagle()
{
    setPixmap(QPixmap(":/images/Eagle.png").scaled(50,50));
}

